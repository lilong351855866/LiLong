# "Quad-Remesher Bridge for Blender"
# Author : Maxime Rouca
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, see <http://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

bl_info = {
	"name": "♜一键重拓扑(Quad Remesher Bridge)",
	"author": "马克西姆  汉化：GJJ",
	"version": (1, 3, 0),
	"blender": (2, 80, 0),
	"description": "以将原来三角面的模型，重新转换成四边形模型",
	"location": "【N面板>♜】或【⌨Ctrl+Alt+R】",
	"warning": "",
	"wiki_url": "",
	"tracker_url": "",
	"category": "Mesh"
}

import bpy
import bpy.props
from rna_keymap_ui import draw_kmi
from bl_operators.presets import AddPresetBase

from .qr_operators import (QREMESHER_OT_remesh, QREMESHER_OT_reset_settings, QREMESHER_OT_license_manager, QREMESHER_OT_facemap_to_materials)

addon_name = __name__.split(".")[0]


#def addon_prefs():
#	return bpy.context.preferences.addons[addon_name].preferences

def paintDensityPropertyCB(self, context):
	#try:
	props = bpy.context.scene.qremesher
	vertexColorSliderValue = getattr(props, 'painted_quad_density')
	
	#print("vertexColorSliderValue = " + str(vertexColorSliderValue) + "\n")

	#Mapping: Slider in [0.25, 4]
	maxSliderValue = 4
	minSliderValue = 0.25
	normalizedValue = 0.0
	if vertexColorSliderValue > 1.0:
		normalizedValue = (vertexColorSliderValue - 1.0) / (maxSliderValue - 1.0)
	elif vertexColorSliderValue < 1.0:
		normalizedValue =  - ((1.0/vertexColorSliderValue) - 1.0) / ((1.0/minSliderValue) - 1.0)

	if (normalizedValue > 1):
		normalizedValue = 1
	if (normalizedValue < -1):
		normalizedValue = -1

	# -- normalizedValue to color
	r = 1.0
	g = 1.0
	b = 1.0
	if normalizedValue > 0.0:
		r = 1
		g = 1-normalizedValue
		b = 1-normalizedValue
	elif normalizedValue < 0.0:
		r = 1+normalizedValue
		g = 1
		b = 1
		
	# set the color
	mycolor=(r, g, b)
	bpy.data.brushes["Draw"].color = mycolor

	#except Exception:
	#	print("异常：在paintDensityPropertyCB中..\n")
	return
    
# ----- Properties container ------
class QRSettingsPropertyGroup(bpy.types.PropertyGroup):
	# Target Quad Count
	target_count: bpy.props.IntProperty(name="四元数量", description="设置所需的四边形数",
										default=5000, soft_min=100, soft_max=10000, step=20, min = 1)

	curvatureAdaptivness_Tooltip = "允许控制四边形的大小如何局部适应曲率。\n它越高,在高曲率区域上的四边形就越小。\n将其设置为0,以获得统一的四边形大小"
	adaptQuadCount_Tooltip = "自适应四边形数量：打开：创建比要求的多边形更多的多边形来适应高曲率区域关闭(默认)：更准确地尊重目标四边形数量。\n建议让它“关闭”,以更好地尊重目标四方数量。有关更多解释,请参阅文档. "
	useVertexColors_Tooltip = "使用“顶点颜色”控制四边形大小密度."
	vertexColorWidget_Tooltip = "定义要绘制的颜色以局部控制所需的四密度变化(在“顶点绘制”模式下使用“绘制”工具)\n。从0.25=>“将密度除以4”=大四边形=青色\n。到4=>“密度乘以4”=小四边形=红色."
	useMaterials_Tooltip="如果启用,QuadRemesher将使用现有的“材质”来指导材质边界上的四重网格。\n材质ID将在重新打磨后进行维护."
	useNormals_Tooltip="注意：此选项在特定情况下可用,但默认情况下应为“关闭”(镶嵌网格)。阅读文档了解更多信息..."
	useNormals_Tooltip+="\n如果启用,QuadRemesher将使用现有的“法向”来引导对法向进行分割/锐化的边循环进行重新网格化。\n默认情况下,Blenders会创建法向处处分割的网格。\n仅在启用SmoothShade+AutoSmooth的情况下启用此选项是有用的…\n对于平滑的有机形状,建议禁用它."
	detectHardEdges_Tooltip="如果启用,QuadRemesher将根据几何结构自动检测/计算硬边(使用边的角度和其他几何因子的混合)这很有用,因为你还没有定义一些硬化/软化边,如果你想让QuadRemesher自动找到硬角度。\n如果选中“使用现有硬/软边”,最好取消选中“检测硬边”。\n对于平滑的有机形状,建议禁用它."
	symToolTip = "这些选项允许执行对称四边形重新网格。可以组合所有3个对称轴."
	#symToolTip += "\n小心：轴是局部坐标轴！建议将Gizmo设置为“对象”模式,以便更好地查看“局部坐标”轴."
	
	# Quads size settings
	adaptive_size: bpy.props.FloatProperty(name="自适应大小", 
										 description=curvatureAdaptivness_Tooltip,
										 default=50, min=0, max=100, step=0.5, precision=0, subtype = 'PERCENTAGE')

	adapt_quad_count: bpy.props.BoolProperty(name="自适应四进制数量", default=True, 
											description=adaptQuadCount_Tooltip)
	
	use_vertex_color: bpy.props.BoolProperty(name="使用顶点颜色", 
											description=useVertexColors_Tooltip,
											default=False)

	painted_quad_density: bpy.props.FloatProperty(name="四边形密度(绘制)", 
											description=vertexColorWidget_Tooltip,
										   default=1.0, min=0.25, max=4.0, step=0.4,
										   update=paintDensityPropertyCB)

	# Edge loops control
	use_materials: bpy.props.BoolProperty(name="使用材质", default=False, 
											description = useMaterials_Tooltip)
	use_normals: bpy.props.BoolProperty(name="使用法向拆分", 
										default=False,					#because when I create a sphere, all edges are 'creased', not a good idea to enable this by default...
										description=useNormals_Tooltip)
	autodetect_hard_edges: bpy.props.BoolProperty(name="按角度检测硬边", 
													default=True, 
													description=detectHardEdges_Tooltip)

	# Misc category
	symmetry_x: bpy.props.BoolProperty(name="X", default=False, description=symToolTip)
	symmetry_y: bpy.props.BoolProperty(name="Y", default=False, description=symToolTip)
	symmetry_z: bpy.props.BoolProperty(name="Z", default=False, description=symToolTip)
	
	# progress bar value
	progress_value: bpy.props.FloatProperty(default=0, subtype='PERCENTAGE', precision=1, min=0, soft_min=0, soft_max=100, max=100)
    

def draw_panel_content(context, layout):
	#print("draw_panel_content已调用")
	
	props = context.scene.qremesher
	#props = addon_prefs().props

	wm = context.window_manager

	# "REMESH IT" button
#	if QREMESHER_OT_remesh.IsRemeshing:
#		myrow = layout.row(align=True)
#		myrow.label(text="(ESC)")
#		myrow.prop(props, 'progress_value')
#		#layout.prop(props, 'progress_value')
	layout.operator(QREMESHER_OT_remesh.bl_idname)
	layout.separator()
		
	# Settings
	col = layout.column(align=True)
	# row = col.row(align=True)
	col.prop(props, 'target_count')

	col.separator()

	# --- Quad Size settings.... ---
	box = col.box()
	box.label(text="  四边形大小设置...")

	box.prop(props, 'adaptive_size')
	box.prop(props, 'adapt_quad_count')
	box.prop(props, 'use_vertex_color')

	box.separator()
	box.prop(props, 'painted_quad_density')

	col.separator()

	# --- Quad Size settings.... ---
	box = col.box()
	box.label(text="  边循环控制...")

	box.prop(props, 'use_materials')
	box.prop(props, 'use_normals')
	box.prop(props, 'autodetect_hard_edges')

	col.separator()

	# --- Misc.... ---
	box = col.box()
	box.label(text="  杂项...")
	box.label(text="对称性:")
	myrow = box.row(align=True)
	myrow.prop(props, 'symmetry_x')
	myrow.prop(props, 'symmetry_y')
	myrow.prop(props, 'symmetry_z')
	box.operator(QREMESHER_OT_reset_settings.bl_idname)
	if bpy.app.version < (4, 0, 0):box.operator(QREMESHER_OT_facemap_to_materials.bl_idname)



# Side panel ui
class QREMESHER_PT_qremesher(bpy.types.Panel):
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = '♜'		# name of the VerticalTab
	bl_label = "♜一键重拓扑(Quad Remesher Bridge)"

	bl_idname = "QREMESHER_PT_qremesher"

	# bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return True

	def draw(self, context):
		row=self.layout.row()
		row.operator("wm.url_open", text="插件视频",icon="FILE_MOVIE").url = "https://www.bilibili.com/video/BV1gc411v7XN/"
		row.operator("wm.url_open", text="更多插件",icon="COLORSET_09_VEC").url = "https://space.bilibili.com/454791153/video"
		draw_panel_content(context, self.layout)


# Scene settings subpanel
'''
class QREMESHER_PT_qremesher_setting_panel(bpy.types.Panel):
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = '♜'
	bl_label = "设置"

	bl_idname = "QREMESHER_PT_qremesher_setting_panel"
	bl_parent_id = "QREMESHER_PT_qremesher"   # NB: ca suffit a ajouter ce sub panel dans le panel QREMESHER_PT_qremesher

	# bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		return True

	def draw(self, context):

		self.layout.operator(QREMESHER_OT_reset_settings.bl_idname)

		self.layout.separator()

		#draw_panel_content(context, self.layout)
'''


classes = [QRSettingsPropertyGroup,

		   QREMESHER_PT_qremesher,
		   #QREMESHER_PT_qremesher_setting_panel,

		   QREMESHER_OT_remesh,
		   QREMESHER_OT_reset_settings,
		   QREMESHER_OT_license_manager,
		   QREMESHER_OT_facemap_to_materials,
		   ]
addon_keymaps = []


def hotkeys():
	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon

	if kc:
		if '3D View' not in kc.keymaps:
			km_view3d = kc.keymaps.new('3D View', space_type='VIEW_3D', region_type='WINDOW')
		else:
			km_view3d = kc.keymaps['3D View']

		kmi = km_view3d.keymap_items.new(QREMESHER_OT_remesh.bl_idname, head=True, type='R', value='PRESS',
										 ctrl=True, alt=True)

		addon_keymaps.append((km_view3d, kmi))


def register():
	for cls in classes:
		bpy.utils.register_class(cls)

	bpy.types.Scene.qremesher = bpy.props.PointerProperty(type=QRSettingsPropertyGroup)

	hotkeys()


def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)

	del bpy.types.Scene.qremesher

	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon

	if kc:
		for km, kmi in addon_keymaps:
			km.keymap_items.remove(kmi)
	addon_keymaps.clear()
